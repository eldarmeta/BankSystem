package com.bank;

public final class CheckingAccount extends Account {
    private final double dailyWithdrawLimit;

    public CheckingAccount() {
        super();
        this.dailyWithdrawLimit = 500.0;
    }

    public CheckingAccount(String ownerName, String pin) {
        super(ownerName, pin);
        this.dailyWithdrawLimit = 500.0;
    }

    public CheckingAccount(String ownerName, String pin, double initialDeposit, double dailyWithdrawLimit) {
        super(ownerName, pin, initialDeposit);
        if (dailyWithdrawLimit <= 0) throw new IllegalArgumentException("limit");
        this.dailyWithdrawLimit = dailyWithdrawLimit;
    }

    @Override
    public void withdraw(double amount) {
        if (amount > dailyWithdrawLimit) throw new IllegalStateException("limit exceeded");
        super.withdraw(amount);
    }

    @Override
    public String accountType() {
        return "CHECKING";
    }
}