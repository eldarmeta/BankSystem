package com.bank;

import java.util.*;

public final class User {
    private final String name;
    private final Map<String, Account> accounts = new LinkedHashMap<>();

    public User(String name) {
        if (name == null || name.isBlank()) throw new IllegalArgumentException("name");
        this.name = name.trim();
    }

    public String name() {
        return name;
    }

    public Collection<Account> accounts() {
        return Collections.unmodifiableCollection(accounts.values());
    }

    public Account open(Account account) {
        accounts.put(account.number(), account);
        return account;
    }

    public Optional<Account> find(String accountNumber) {
        return Optional.ofNullable(accounts.get(accountNumber));
    }
}