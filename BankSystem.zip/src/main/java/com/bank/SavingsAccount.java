package com.bank;

public final class SavingsAccount extends Account {
    private final double interestRate;

    public SavingsAccount() {
        super();
        this.interestRate = 0.02;
    }

    public SavingsAccount(String ownerName, String pin) {
        super(ownerName, pin);
        this.interestRate = 0.02;
    }

    public SavingsAccount(String ownerName, String pin, double initialDeposit, double interestRate) {
        super(ownerName, pin, initialDeposit);
        if (interestRate < 0) throw new IllegalArgumentException("rate");
        this.interestRate = interestRate;
    }

    public void applyMonthlyInterest() {
        balance += balance * interestRate / 12.0;
    }

    @Override
    public String accountType() {
        return "SAVINGS";
    }
}