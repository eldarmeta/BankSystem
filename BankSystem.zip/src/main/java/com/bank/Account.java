package com.bank;

import java.util.UUID;

public abstract class Account {
    protected final String accountNumber;
    protected double balance;
    protected String ownerName;
    protected String pin;

    protected Account() {
        this.accountNumber = UUID.randomUUID().toString();
        this.balance = 0.0;
        this.ownerName = "Unknown";
        this.pin = "0000";
    }

    protected Account(String ownerName, String pin) {
        this.accountNumber = UUID.randomUUID().toString();
        this.balance = 0.0;
        this.ownerName = ownerName;
        this.pin = pin;
    }

    protected Account(String ownerName, String pin, double initialDeposit) {
        this.accountNumber = UUID.randomUUID().toString();
        this.balance = initialDeposit;
        this.ownerName = ownerName;
        this.pin = pin;
    }

    public String number() {
        return accountNumber;
    }

    public double balance() {
        return balance;
    }

    public String owner() {
        return ownerName;
    }

    public void renameOwner(String newName) {
        if (newName == null || newName.isBlank()) throw new IllegalArgumentException("name");
        this.ownerName = newName;
    }

    public void changePin(String newPin) {
        if (newPin == null || newPin.length() < 4) throw new IllegalArgumentException("pin");
        this.pin = newPin;
    }

    public void deposit(double amount) {
        if (amount <= 0) throw new IllegalArgumentException("amount");
        balance += amount;
    }

    public void withdraw(double amount) {
        if (amount <= 0) throw new IllegalArgumentException("amount");
        if (amount > balance) throw new IllegalStateException("insufficient funds");
        balance -= amount;
    }

    public abstract String accountType();
}