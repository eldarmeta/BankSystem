package com.bank;

public final class App {
    public static void main(String[] args) {
        var bank = new BankService();
        var eldar = bank.registerUser("Eldar");
        var savings = (SavingsAccount) eldar.open(new SavingsAccount("Eldar","1234",500,0.03));
        var checking = (CheckingAccount) eldar.open(new CheckingAccount("Eldar","5678",200,600));
        var business = (BusinessAccount) eldar.open(new BusinessAccount("Eldar","9999",1000,1500));
        savings.deposit(200);
        savings.applyMonthlyInterest();
        checking.withdraw(300);
        bank.transfer(savings, business, 250);
        business.withdraw(2000);
        for (var a : eldar.accounts()) {
            System.out.println(a.accountType()+": "+a.number()+" | "+a.owner()+" | "+a.balance());
        }
    }
}