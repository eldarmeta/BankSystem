package com.bank;

public final class BusinessAccount extends Account {
    private final double creditLimit;

    public BusinessAccount() {
        super();
        this.creditLimit = 1000.0;
    }

    public BusinessAccount(String ownerName, String pin) {
        super(ownerName, pin);
        this.creditLimit = 1000.0;
    }

    public BusinessAccount(String ownerName, String pin, double initialDeposit, double creditLimit) {
        super(ownerName, pin, initialDeposit);
        if (creditLimit < 0) throw new IllegalArgumentException("limit");
        this.creditLimit = creditLimit;
    }

    @Override
    public void withdraw(double amount) {
        if (amount <= 0) throw new IllegalArgumentException("amount");
        if (amount > balance + creditLimit) throw new IllegalStateException("exceeds credit");
        balance -= amount;
    }

    @Override
    public String accountType() {
        return "BUSINESS";
    }
}