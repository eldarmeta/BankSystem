package com.bank;

import java.util.*;

public final class BankService {
    private final Map<String, User> users = new HashMap<>();

    public User registerUser(String name) {
        var user = new User(name);
        users.put(user.name(), user);
        return user;
    }

    public User getUser(String name) {
        var user = users.get(name);
        if (user == null) throw new NoSuchElementException("user");
        return user;
    }

    public void transfer(Account from, Account to, double amount) {
        if (from == null || to == null) throw new IllegalArgumentException("account");
        if (from == to) throw new IllegalArgumentException("same account");
        from.withdraw(amount);
        to.deposit(amount);
    }
}